{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "keywords": "贤心是男是女"
    ,"frequency": 8520
    ,"userNums": 2216
  },{
    "keywords": "Java程序员能找到女朋友吗"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "此表格是静态模拟数据"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  },{
    "keywords": "layui官方教程"
    ,"frequency": 666
    ,"userNums": 333
  }]
}